<?php
require 'config/config.php';
// custom autoloader
require 'helpers/Autoload.php';
// composer autoloader
require 'vendor/autoload.php';
Autoload::register();


$page = $_GET['page'] ?? 'home';

if ($page === 'home') {
    $controller = new App\Controllers\Player();
    $controller->index();
} else {
    // team/show
    $page = explode('/', $page);

    $controller_name = 'App\\Controllers\\' . ucfirst($page[0]);
    $method_name = $page[1];

    $router = new $controller_name();

    $router->$method_name();
}