<?php
namespace App\Models;

use App\Databases\Database;
use \PDO;
abstract class Model
{
    protected $db;

    protected $table;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    public function hydrate(array $data)
    {
        foreach ($data as $key => $val) {
            $method = 'set' . ucfirst($key);

            if (method_exists($this, $method)) {
                $this->$method($val);
            }
        }
    }
    public function __get($property)
    {
        if (property_exists($this, $property)) {
            return $this->$property;
        }
    }

    function delete()
    {

        $stmt = $this->db->prepare('DELETE FROM '. $this->table .' WHERE `player_id` = ?');


        return $stmt->execute([$this->player_id]);
    }

    public function getOne()
    {

        $stmt = $this->db->prepare('SELECT * FROM ' . $this->table . ' WHERE `player_id` = ?');


        $stmt->execute([$this->player_id]);


        $team = $stmt->fetch();

        $this->hydrate($team);
    }
    
    public function getOneTeam()
    {

        $stmt = $this->db->prepare('SELECT * FROM ' . $this->table . ' WHERE `team_id` = ?');


        $stmt->execute([$this->team_id]);


        $division = $stmt->fetch();

        $this->hydrate($division);
    }

    public function getAll()
    {

        $stmt = $this->db->query('SELECT * FROM ' . $this->table);



        $teams = $stmt->fetchAll();

        return $teams;
    }

    
    public function getDb()
    {
        return $this->db;
    }
}
