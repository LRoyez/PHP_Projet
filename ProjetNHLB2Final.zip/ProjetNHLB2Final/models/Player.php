<?php

namespace App\Models;

use Exception;
use PDO;
use PDOException;

class Player extends Model
{
    private $player_id;
    private $player_name;
    private $team_id;

    protected $table = 'players';
    public function getAllWithTeam()
    {

        $sql = "SELECT
            `players`.`player_id`,
            `players`.`player_name`,
            `teams`.`team_id`,
            `teams`.`team_name`,
            `teams`.`logo`,
            `players`.`player_img`

         FROM
            `players`
        INNER JOIN `teams` ON `players`.`team_id` = `teams`.`team_id`";
        $stmt = $this->db->query($sql);
        $players = $stmt->fetchAll();
        return $players;
    }

    public function team()
    {

        $stmt = $this->db->prepare('SELECT * FROM `teams` WHERE `team_id` = ?');


        $stmt->execute([$this->team_id]);
        $team = $stmt->fetch(\PDO::FETCH_OBJ);
        return $team;
    }


    public function __get($property)
    {
        if (property_exists($this, $property)) {
            return $this->$property;
        }
    }

    
    public function getPlayer_id()
    {
        return $this->player_id;
    }

    /**
     * 
     * @return  self
     */
    public function setPlayer_id($player_id)
    {
        $this->player_id = $player_id;

        return $this;
    }

    
    public function getPlayer_name()
    {
        return $this->player_name;
    }

    /**
     *
     * @return  self
     */
    public function setPlayer_name($player_name)
    {
        $this->player_name = $player_name;

        return $this;
    }

    
    public function getTeam_id()
    {
        return $this->team_id;
    }

    /**
     * 
     * @return  self
     */
    public function setTeam_id($team_id)
    {
        $this->team_id = $team_id;

        return $this;
    }

    public function create()
    {
        $sql = "INSERT INTO `players` (`player_id`, `player_name`, `team_id`) VALUES (:player_id, :player_name, :team_id)";

        $stmt = $this->db->prepare($sql);

        $stmt->bindValue(':player_id', $this->player_id, PDO::PARAM_INT);
        $stmt->bindValue(':player_name', $this->player_name, PDO::PARAM_STR);
        $stmt->bindValue(':team_id', $this->team_id, PDO::PARAM_INT);

        try {
            $result = $stmt->execute();
            return $result;
        } catch (PDOException $e) {
            echo sprintf('Erreur lors de l\'insertion des données : %s', $e->getMessage());

            throw new Exception('Echec de l\'insertion du joueur');
        }
    }

    public function update()
    {
        $sql = "UPDATE `players` SET `player_id` = :player_id , `player_name` = :player_name, `team_id` = :team_id WHERE `player_id` = :player_id";
        $stmt = $this->db->prepare($sql);

        $stmt->bindValue(':player_id', $this->player_id, PDO::PARAM_INT);
        $stmt->bindValue(':player_name', $this->player_name, PDO::PARAM_STR);
        $stmt->bindValue(':team_id', $this->team_id, PDO::PARAM_INT);

        try {
            $result = $stmt->execute();
            return $result;
        } catch (PDOException $e) {
            echo sprintf('Erreur lors de la modification des données : %s', $e->getMessage());
            return false;
        }
    }
}
