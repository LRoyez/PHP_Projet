<?php 
namespace App\Models;

class Division extends Model {
    protected $table = 'divisions';
}