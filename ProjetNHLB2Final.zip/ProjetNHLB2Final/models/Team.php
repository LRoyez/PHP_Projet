<?php

namespace App\Models;

use PDOException;
use PDO;

class Team extends Model
{
    private $team_id;
    private $team_name;
    private $team_code;
    private $division_id;

    protected $table = 'teams';

    public function players()
    {

        $stmt = $this->db->prepare('SELECT * FROM `players` WHERE `team_id` = ?');


        $stmt->execute([$this->id]);
        $players = $stmt->fetchAll(\PDO::FETCH_OBJ);
        return $players;
    }

    public function __get($property)
    {
        if (property_exists($this, $property)) {
            return $this->$property;
        }
    }

    
    public function getTeam_id()
    {
        return $this->team_id;
    }

    /**
     * 
     * @return  self
     */
    public function setTeam_id($team_id)
    {
        $this->team_id = $team_id;

        return $this;
    }

    
    public function getTeam_name()
    {
        return $this->name;
    }

    /**
     * 
     * @return  self
     */
    public function setTeam_name($team_name)
    {
        $this->team_name = $team_name;

        return $this;
    }

    
    public function getTeam_code()
    {
        return $this->team_code;
    }

    /**
     * 
     * @return  self
     */
    public function setTeam_code($team_code)
    {
        $this->team_code = $team_code;

        return $this;
    }
    
    public function getDivision_id()
    {
        return $this->division_id;
    }
    /**
     * 
     * @return self
     */
    public function setDivision_id($division_id)
    {
        $this->division_id = $division_id;

        return $this;
    }

    /**
     * @return self
     */
    public function create()
    {
        $sql = "INSERT INTO `teams` (`team_id`,`team_name`, `team_code`,`division_id`) VALUES (:team_id ,:team_name, :team_code, :division_id)";

        $stmt = $this->db->prepare($sql);
        $stmt->bindValue(':team_id', $this->team_id, PDO::PARAM_INT);
        $stmt->bindValue(':team_name', $this->team_name, PDO::PARAM_STR);
        $stmt->bindValue(':team_code', $this->team_code, PDO::PARAM_STR);
        $stmt->bindValue(':division_id', $this->division_id, PDO::PARAM_INT);

        if ($stmt->execute()) {
            $lastInsert = $this->db->lastInsertId();
            $this->team_id = $lastInsert;
            return $this;
        }
        throw new \Exception('erreur lors de l\'insertion');
    }
    public function update()
    {
        $sql = "UPDATE `teams` SET `team_id` = :team_id , `team_name` = :team_name, `team_code` = :team_code, `division_id` = :division_id WHERE `team_id` = :team_id";
        $stmt = $this->db->prepare($sql);

        $stmt->bindValue(':team_id', $this->team_id, PDO::PARAM_INT);
        $stmt->bindValue(':team_name', $this->team_name, PDO::PARAM_STR);
        $stmt->bindValue(':team_code', $this->team_code, PDO::PARAM_STR);
        $stmt->bindValue(':division_id', $this->division_id, PDO::PARAM_INT);

        try {
            $result = $stmt->execute();
            return $result;
        } catch (PDOException $e) {
            echo sprintf('Erreur lors de la modification des données : %s', $e->getMessage());
            return false;
        }
    }
}
