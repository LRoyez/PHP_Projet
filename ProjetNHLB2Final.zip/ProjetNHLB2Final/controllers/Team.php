<?php

namespace App\Controllers;

use App\Helpers\Validator;
use App\Helpers\HttpRequest;
use App\Models\Team as TeamModel;
use App\Models\Player as PlayerModel;
use App\Models\Division as DivisionModel;
use App\Libraries\Form_validator;
use App\Models\Division;

class Team extends Controller
{
    /**
     * GET 
     * 
     * @return void
     */
    public function index()
    {
    }
    /**
     * GET 
     * 
     * @return void
     */
    public function show()
    {

        $team_id = Validator::checkId($_GET['team_id']);

        if (!$team_id) {
            HttpRequest::redirectTo('index');
        }

        $team = new TeamModel();

        $team->setTeam_id($team_id);

        $team->getOne();

        $players = $team->players();

        $title = $team->name;

        $heading = $team->name;

        echo $this->twig->render('teams/show.html.twig', compact('team_name', 'heading', 'players', 'team'));
    }
    /**
     * GET / POST
     * Affiche le formulaire de création
     * @return void
     */
    public function create()
    {
        $data = [
            'team_name' => '',
            'team_code' => '',
            'division_id' => ''     
        ];

        $errors = array();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {

            $data = $_POST;

            $form_validator = new Form_validator();

            $form_validator->make($data, [
                'team_name' => 'required|alpha',
                'team_code' => 'required|alpha',
                'division_id' => 'required|integer'
            ]);

            if ($form_validator->isValid()) {

            $team = new TeamModel();

            $team->hydrate($data);


            try {
                $team->create();
                var_dump($team);
            } catch (\Exception $e) {
                var_dump($e->getMessage());
                die;
            }
        }
            $errors = $form_validator->getErrors();
        }
        $division = new Division();
        $divisions = $division->getAll();
        
        $title = 'Ajouter une équipe';
        $heading = 'Enregister une équipe';
        echo $this->twig->render('teams/create.html.twig', compact('title', 'heading', 'data', 'errors', 'divisions'));
    }
    public function update()
    {
        
        $team_id = Validator::checkId($_GET['team_id']);


        if (!$team_id) {
            HttpRequest::redirectTo('index');
        }


        $team = new TeamModel();

        $team->setTeam_id($team_id);


        $team->getOneTeam();

        $title = $team->title;

        $heading = $team->title;


        
        $data = [
            'team_id' => $team->team_id,
            'team_name' => $team->team_name,
            'team_code' => $team->team_code,
            'division_id' => $team->division_id
        ];
        $errors = array();
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {


            $data = $_POST;
            $form_validator = new Form_Validator();

            $form_validator->make($data, [
                'team_name' => 'required|alpha',
                'team_code' => 'required|alpha',
                'division_id' => 'required|integer'
            ]);

            if ($form_validator->isValid()) {


                $team->hydrate($data);
                if ($team->update()) {
                    HttpRequest::redirectTo('index');
                }
            }
            $errors = $form_validator->getErrors();
        }
        $division = new DivisionModel();
        $divisions = $division->getAll();
        // var_dump($divisions);

        echo $this->twig->render('teams/update.html.twig', compact('team_name', 'heading', 'divisions', 'data', 'errors'));
    }
    /**
     * GET / POST
     * @return void
     */
    public function delete()
    {

        $team_id = Validator::checkId($_POST['team_id']);


        if (!$team_id) {
            HttpRequest::redirectTo('index');
        }


        $team = new TeamModel();

        $team->setTeam_id($team_id);

        $team->delete();
        
        HttpRequest::redirectTo('index');
    }
}

