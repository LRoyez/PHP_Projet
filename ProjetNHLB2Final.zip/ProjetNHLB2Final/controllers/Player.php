<?php

namespace App\Controllers;

use App\Helpers\HttpRequest;
use App\Helpers\Validator;
use App\Models\Team as TeamModel;
use App\Models\Player as PlayerModel;
use App\Libraries\Form_validator;

class Player extends Controller
{
    /**
     * GET
     * @return void
     */
    public function index()
    {

        $player = new PlayerModel();

        $players = $player->getAllWithTeam();

        $title = 'Accueil';

        $heading = 'WikNHL';

        echo $this->twig->render('players/index.html.twig', compact('players', 'heading', 'player_name'));
    }

    /**
     * GET
     * 
     * @return void
     */
    public function show()
    {
        $player_id = Validator::checkId($_GET['player_id']);


        if (!$player_id) {
            HttpRequest::redirectTo('index');
        }


        $player = new PlayerModel();

        $player->setPlayer_id($player_id);


        $player->getOne();

        $team = $player->team();

        $title = $player->title;

        $heading = $player->title;

        echo $this->twig->render('players/show.html.twig', compact('player_name', 'heading', 'player', 'team'));
    }
    /**
     * GET / POST
     * 
     * @return void
     */
    public function create()
    {
        
        $data = [
            'player_name' => '',
            'team_id' => ''
        ];
    
        $errors = array();
 
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    


            $data = $_POST;
            
            $form_validator = new Form_Validator();

     
            $form_validator->make($data, [
                'player_name' => 'required|alpha',
                'team_id' => 'required|integer'
            ]);

        
            if ($form_validator->isValid()) {
              

                $player = new PlayerModel();

                $player->hydrate($data);
                if ($player->create()) {
                    HttpRequest::redirectTo('index');
                }
            }
  
            $errors = $form_validator->getErrors();
        }

        $team = new TeamModel();
        $teams = $team->getAll();
        $title = 'Ajouter un joueur';
        $heading = 'Enregister un nouveau joueur';
        echo $this->twig->render('players/create.html.twig', compact('player_name', 'heading', 'teams', 'data', 'errors'));
    }
    /**
     * GET / POST
     * 
     * @return void
     */
    public function update()
    {
        
        $player_id = Validator::checkId($_GET['player_id']);


        if (!$player_id) {
            HttpRequest::redirectTo('index');
        }


        $player = new PlayerModel();

        $player->setPlayer_id($player_id);


        $player->getOne();

        $title = $player->title;

        $heading = $player->title;


        
        $data = [
            'player_id' => $player->player_id,
            'player_name' => $player->player_name,
            'team_id' => $player->team_id
        ];
        $errors = array();
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {


            $data = $_POST;
            $form_validator = new Form_Validator();

            $form_validator->make($data, [
                'player_name' => 'required|alpha',
                'team_id' => 'required|integer'
            ]);

            if ($form_validator->isValid()) {


                $player->hydrate($data);
                if ($player->update()) {
                    HttpRequest::redirectTo('index');
                }
            }
            $errors = $form_validator->getErrors();
        }
        $team = new TeamModel();
        $teams = $team->getAll();

        echo $this->twig->render('players/update.html.twig', compact('player_name', 'heading', 'teams', 'data', 'errors'));
    }
    /**
     * GET / POST
     * @return void
     */
    public function delete()
    {

        $player_id = Validator::checkId($_POST['player_id']);


        if (!$player_id) {
            HttpRequest::redirectTo('index');
        }


        $player = new PlayerModel();

        $player->setPlayer_id($player_id);

        $player->delete();
        
        HttpRequest::redirectTo('index');
    }
}
